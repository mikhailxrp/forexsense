import { BrowserRouter, Routes, Route } from 'react-router';
import '../styles/bootstrap-custom.css';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import AnalysisResult from './components/AnalysisResult';
import History from './components/History';

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/analysis/:pair" element={<AnalysisResult />} />
          <Route path="/history" element={<History />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}