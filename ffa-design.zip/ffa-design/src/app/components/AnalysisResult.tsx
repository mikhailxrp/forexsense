import { useNavigate, useParams } from 'react-router';
import { ArrowLeft, TrendingUp, TrendingDown, Minus } from 'lucide-react';

const MOCK_DATA = {
  'EUR-USD': {
    pair: 'EUR/USD',
    sentiment: 'Bullish',
    signalStrength: 4,
    baseCurrency: 'EUR',
    baseSummary: 'European Central Bank maintains hawkish stance. GDP growth exceeds expectations at 2.1%.',
    quoteCurrency: 'USD',
    quoteSummary: 'Fed signals potential rate pause. Labor market shows signs of cooling.',
    events: [
      { time: '08:30', event: 'US Non-Farm Payrolls', currency: 'USD', impact: 'High' },
      { time: '10:00', event: 'Eurozone CPI', currency: 'EUR', impact: 'High' },
      { time: '12:00', event: 'ECB Speech', currency: 'EUR', impact: 'Medium' },
      { time: '14:30', event: 'US Retail Sales', currency: 'USD', impact: 'Medium' },
      { time: '16:00', event: 'Fed Minutes Release', currency: 'USD', impact: 'High' }
    ],
    recommendation: 'Current fundamental factors support a bullish outlook for EUR/USD. The European Central Bank\'s commitment to fighting inflation, combined with stronger-than-expected GDP growth in the Eurozone, provides solid support for the euro. Meanwhile, the Federal Reserve\'s dovish pivot and cooling US labor market suggest potential USD weakness. Key resistance level at 1.0950. Watch for ECB commentary and US employment data for confirmation of trend continuation.',
    news: [
      {
        source: 'Reuters',
        headline: 'ECB Officials Signal Continued Rate Hikes Amid Inflation Concerns',
        summary: 'European Central Bank policymakers indicated they are prepared to continue raising interest rates as inflation remains above target levels.',
        timestamp: '2 hours ago'
      },
      {
        source: 'Bloomberg',
        headline: 'US Jobs Report Shows Slower Hiring Pace',
        summary: 'Latest employment data reveals a deceleration in job creation, potentially giving the Fed room to pause rate hikes.',
        timestamp: '3 hours ago'
      },
      {
        source: 'Financial Times',
        headline: 'Eurozone Economy Beats Growth Forecasts',
        summary: 'GDP growth in the euro area exceeded analyst expectations, driven by strong manufacturing and services sectors.',
        timestamp: '5 hours ago'
      },
      {
        source: 'Wall Street Journal',
        headline: 'Dollar Weakens on Fed Rate Pause Speculation',
        summary: 'The US dollar declined against major currencies as markets price in a potential pause in the Federal Reserve\'s tightening cycle.',
        timestamp: '6 hours ago'
      }
    ]
  },
  'GBP-USD': {
    pair: 'GBP/USD',
    sentiment: 'Bearish',
    signalStrength: 3,
    baseCurrency: 'GBP',
    baseSummary: 'Bank of England faces recession concerns. UK inflation remains stubbornly high.',
    quoteCurrency: 'USD',
    quoteSummary: 'Strong US economic data supports dollar strength. Fed maintains restrictive policy.',
    events: [
      { time: '07:00', event: 'UK GDP Report', currency: 'GBP', impact: 'High' },
      { time: '08:30', event: 'BoE Interest Rate Decision', currency: 'GBP', impact: 'High' },
      { time: '13:00', event: 'US FOMC Statement', currency: 'USD', impact: 'High' },
      { time: '15:00', event: 'US Consumer Confidence', currency: 'USD', impact: 'Medium' }
    ],
    recommendation: 'Fundamental analysis suggests downside pressure for GBP/USD. The UK economy faces headwinds from persistent inflation and recession risks, while the Bank of England struggles to balance growth concerns with price stability. In contrast, the US economy shows resilience with the Federal Reserve maintaining a hawkish stance. Support level at 1.2450 may be tested. Monitor BoE policy decisions and UK economic indicators for trend confirmation.',
    news: [
      {
        source: 'BBC News',
        headline: 'Bank of England Warns of Prolonged Economic Weakness',
        summary: 'BoE Governor highlights challenges facing the UK economy, including high inflation and weak growth prospects.',
        timestamp: '1 hour ago'
      },
      {
        source: 'Reuters',
        headline: 'Sterling Falls as Recession Fears Mount',
        summary: 'The British pound weakened against the dollar amid growing concerns about a potential UK recession.',
        timestamp: '4 hours ago'
      },
      {
        source: 'CNBC',
        headline: 'Fed Officials Reiterate Commitment to Price Stability',
        summary: 'Federal Reserve policymakers emphasized their determination to bring inflation back to the 2% target.',
        timestamp: '5 hours ago'
      },
      {
        source: 'The Guardian',
        headline: 'UK Inflation Remains Above Target Despite Rate Hikes',
        summary: 'Latest data shows UK consumer prices continue to rise at elevated levels, complicating the Bank of England\'s policy decisions.',
        timestamp: '7 hours ago'
      }
    ]
  }
};

export default function AnalysisResult() {
  const navigate = useNavigate();
  const { pair } = useParams();
  const data = MOCK_DATA[pair as keyof typeof MOCK_DATA] || MOCK_DATA['EUR-USD'];

  const getSentimentIcon = () => {
    switch (data.sentiment) {
      case 'Bullish':
        return <TrendingUp size={48} className="text-success" />;
      case 'Bearish':
        return <TrendingDown size={48} className="text-danger" />;
      default:
        return <Minus size={48} className="text-secondary" />;
    }
  };

  const getSentimentColor = () => {
    switch (data.sentiment) {
      case 'Bullish': return 'text-success';
      case 'Bearish': return 'text-danger';
      default: return 'text-secondary';
    }
  };

  const getImpactClass = (impact: string) => {
    switch (impact) {
      case 'High': return 'impact-high';
      case 'Medium': return 'impact-medium';
      default: return 'impact-low';
    }
  };

  return (
    <div className="container py-4">
      {/* Header */}
      <div className="mb-4">
        <button
          className="btn btn-link text-decoration-none p-0 mb-3"
          onClick={() => navigate('/')}
        >
          <ArrowLeft size={20} className="me-2" />
          Back to Dashboard
        </button>
        <h1 className="display-5 fw-bold mb-2">{data.pair} — Analysis</h1>
        <p style={{ color: '#94a3b8' }}>April 12, 2026</p>
      </div>

      {/* Analysis Overview */}
      <div className="row g-4 mb-5">
        <div className="col-md-3">
          <div className="card h-100">
            <div className="card-body text-center">
              <div className="mb-3">{getSentimentIcon()}</div>
              <h3 className={`h5 mb-0 ${getSentimentColor()}`}>{data.sentiment}</h3>
              <small style={{ color: '#94a3b8' }}>Sentiment</small>
            </div>
          </div>
        </div>

        <div className="col-md-3">
          <div className="card h-100">
            <div className="card-body text-center">
              <div className="signal-strength justify-content-center mb-3" style={{ fontSize: '16px' }}>
                {[1, 2, 3, 4, 5].map(level => (
                  <div
                    key={level}
                    className={`signal-dot ${level <= data.signalStrength ? 'filled' : ''}`}
                    style={{ width: '16px', height: '16px' }}
                  />
                ))}
              </div>
              <h3 className="h5 mb-0">{data.signalStrength}/5</h3>
              <small style={{ color: '#94a3b8' }}>Signal Strength</small>
            </div>
          </div>
        </div>

        <div className="col-md-3">
          <div className="card h-100">
            <div className="card-body">
              <h3 className="h6 mb-2">{data.baseCurrency}</h3>
              <p className="small mb-0" style={{ color: '#94a3b8' }}>{data.baseSummary}</p>
            </div>
          </div>
        </div>

        <div className="col-md-3">
          <div className="card h-100">
            <div className="card-body">
              <h3 className="h6 mb-2">{data.quoteCurrency}</h3>
              <p className="small mb-0" style={{ color: '#94a3b8' }}>{data.quoteSummary}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Key Events */}
      <div className="mb-5">
        <h2 className="h4 mb-3">Key Events Today</h2>
        <div className="card">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Event</th>
                  <th>Currency</th>
                  <th>Impact</th>
                </tr>
              </thead>
              <tbody>
                {data.events.map((event, index) => (
                  <tr key={index}>
                    <td>{event.time}</td>
                    <td>{event.event}</td>
                    <td><span className="badge bg-secondary">{event.currency}</span></td>
                    <td>
                      <span className={`badge ${getImpactClass(event.impact)}`}>
                        {event.impact}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Fundamental Recommendation */}
      <div className="mb-5">
        <h2 className="h4 mb-3">Fundamental Recommendation</h2>
        <div className="card">
          <div className="card-body" style={{ fontSize: '15px', lineHeight: '1.6', color: '#cbd5e1' }}>
            {data.recommendation}
          </div>
        </div>
      </div>

      {/* News Feed */}
      <div className="mb-5">
        <h2 className="h4 mb-3">News Feed</h2>
        <div className="row g-3">
          {data.news.map((item, index) => (
            <div key={index} className="col-md-6">
              <div className="card h-100">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <span className="badge bg-secondary">{item.source}</span>
                    <small style={{ color: '#94a3b8' }}>{item.timestamp}</small>
                  </div>
                  <h3 className="h6 mb-2">{item.headline}</h3>
                  <p className="small mb-0" style={{ color: '#94a3b8' }}>{item.summary}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
