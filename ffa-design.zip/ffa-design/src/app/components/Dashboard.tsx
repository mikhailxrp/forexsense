import { useState } from 'react';
import { useNavigate } from 'react-router';

const CURRENCY_PAIRS = [
  'EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD',
  'USD/CAD', 'NZD/USD', 'EUR/GBP', 'EUR/JPY', 'GBP/JPY'
];

const RECENT_ANALYSES = [
  {
    id: 1,
    pair: 'EUR/USD',
    sentiment: 'Bullish',
    signalStrength: 4,
    timestamp: '2026-04-12 09:45'
  },
  {
    id: 2,
    pair: 'GBP/USD',
    sentiment: 'Bearish',
    signalStrength: 3,
    timestamp: '2026-04-12 08:30'
  },
  {
    id: 3,
    pair: 'USD/JPY',
    sentiment: 'Neutral',
    signalStrength: 2,
    timestamp: '2026-04-12 07:15'
  },
  {
    id: 4,
    pair: 'AUD/USD',
    sentiment: 'Bullish',
    signalStrength: 5,
    timestamp: '2026-04-12 06:00'
  },
  {
    id: 5,
    pair: 'USD/CAD',
    sentiment: 'Bearish',
    signalStrength: 3,
    timestamp: '2026-04-11 18:20'
  }
];

export default function Dashboard() {
  const [selectedPair, setSelectedPair] = useState('EUR/USD');
  const navigate = useNavigate();

  const handleAnalyze = () => {
    navigate(`/analysis/${selectedPair.replace('/', '-')}`);
  };

  const getSentimentClass = (sentiment: string) => {
    switch (sentiment) {
      case 'Bullish': return 'sentiment-bullish';
      case 'Bearish': return 'sentiment-bearish';
      default: return 'sentiment-neutral';
    }
  };

  const getSentimentBadge = (sentiment: string) => {
    switch (sentiment) {
      case 'Bullish': return 'bg-success';
      case 'Bearish': return 'bg-danger';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="container py-5">
      {/* Hero Section */}
      <div className="text-center mb-5">
        <h1 className="display-4 fw-bold mb-4">Currency Pair Analysis</h1>
        <div className="row justify-content-center">
          <div className="col-lg-6">
            <select
              className="form-select form-select-lg mb-3"
              value={selectedPair}
              onChange={(e) => setSelectedPair(e.target.value)}
            >
              {CURRENCY_PAIRS.map(pair => (
                <option key={pair} value={pair}>{pair}</option>
              ))}
            </select>
            <button
              className="btn btn-primary btn-lg px-5"
              onClick={handleAnalyze}
            >
              Analyze
            </button>
          </div>
        </div>
      </div>

      {/* Recent Analyses */}
      <div className="mt-5">
        <h2 className="h4 mb-4">Recent Analyses</h2>
        <div className="row g-4">
          {RECENT_ANALYSES.map(analysis => (
            <div key={analysis.id} className="col-md-6 col-lg-4">
              <div
                className="card h-100"
                style={{ cursor: 'pointer' }}
                onClick={() => navigate(`/analysis/${analysis.pair.replace('/', '-')}`)}
              >
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-start mb-3">
                    <h3 className="h5 mb-0">{analysis.pair}</h3>
                    <span className={`badge ${getSentimentBadge(analysis.sentiment)}`}>
                      {analysis.sentiment}
                    </span>
                  </div>

                  <div className="mb-3">
                    <small className="d-block mb-1" style={{ color: '#94a3b8' }}>Signal Strength</small>
                    <div className="signal-strength">
                      {[1, 2, 3, 4, 5].map(level => (
                        <div
                          key={level}
                          className={`signal-dot ${level <= analysis.signalStrength ? 'filled' : ''}`}
                        />
                      ))}
                    </div>
                  </div>

                  <small style={{ color: '#94a3b8' }}>{analysis.timestamp}</small>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
