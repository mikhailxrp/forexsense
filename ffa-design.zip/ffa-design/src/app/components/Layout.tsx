import { useState } from 'react';
import { Link, useLocation } from 'react-router';
import { BarChart3 } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const [isNavExpanded, setIsNavExpanded] = useState(false);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const handleNavClick = () => {
    setIsNavExpanded(false);
  };

  return (
    <div className="min-vh-100 d-flex flex-column">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark">
        <div className="container">
          <Link className="navbar-brand d-flex align-items-center" to="/" onClick={handleNavClick}>
            <BarChart3 size={28} className="me-2" />
            <span className="fw-bold fs-4">ForexSense</span>
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            onClick={() => setIsNavExpanded(!isNavExpanded)}
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className={`collapse navbar-collapse ${isNavExpanded ? 'show' : ''}`}>
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <Link
                  className={`nav-link ${isActive('/') ? 'active' : ''}`}
                  to="/"
                  onClick={handleNavClick}
                >
                  Dashboard
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className={`nav-link ${isActive('/history') ? 'active' : ''}`}
                  to="/history"
                  onClick={handleNavClick}
                >
                  History
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="py-4 mt-5" style={{ borderTop: '1px solid #30363d' }}>
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <p className="text-muted small mb-0">
                &copy; 2026 ForexSense. All rights reserved.
              </p>
            </div>
            <div className="col-md-6 text-md-end">
              <p className="text-muted small mb-0">
                Fundamental analysis for informed trading decisions
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
