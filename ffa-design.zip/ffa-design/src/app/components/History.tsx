import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Eye } from 'lucide-react';

const HISTORY_DATA = [
  {
    id: 1,
    date: '2026-04-12',
    pair: 'EUR/USD',
    sentiment: 'Bullish',
    signalStrength: 4
  },
  {
    id: 2,
    date: '2026-04-12',
    pair: 'GBP/USD',
    sentiment: 'Bearish',
    signalStrength: 3
  },
  {
    id: 3,
    date: '2026-04-12',
    pair: 'USD/JPY',
    sentiment: 'Neutral',
    signalStrength: 2
  },
  {
    id: 4,
    date: '2026-04-12',
    pair: 'AUD/USD',
    sentiment: 'Bullish',
    signalStrength: 5
  },
  {
    id: 5,
    date: '2026-04-11',
    pair: 'USD/CAD',
    sentiment: 'Bearish',
    signalStrength: 3
  },
  {
    id: 6,
    date: '2026-04-11',
    pair: 'EUR/JPY',
    sentiment: 'Bullish',
    signalStrength: 4
  },
  {
    id: 7,
    date: '2026-04-11',
    pair: 'GBP/JPY',
    sentiment: 'Neutral',
    signalStrength: 3
  },
  {
    id: 8,
    date: '2026-04-10',
    pair: 'EUR/USD',
    sentiment: 'Bullish',
    signalStrength: 3
  },
  {
    id: 9,
    date: '2026-04-10',
    pair: 'USD/CHF',
    sentiment: 'Bearish',
    signalStrength: 4
  },
  {
    id: 10,
    date: '2026-04-10',
    pair: 'NZD/USD',
    sentiment: 'Neutral',
    signalStrength: 2
  }
];

export default function History() {
  const navigate = useNavigate();
  const [filterPair, setFilterPair] = useState('All');
  const [filterDate, setFilterDate] = useState('');

  const getSentimentBadge = (sentiment: string) => {
    switch (sentiment) {
      case 'Bullish': return 'bg-success';
      case 'Bearish': return 'bg-danger';
      default: return 'bg-secondary';
    }
  };

  const uniquePairs = ['All', ...Array.from(new Set(HISTORY_DATA.map(item => item.pair)))];

  const filteredData = HISTORY_DATA.filter(item => {
    const pairMatch = filterPair === 'All' || item.pair === filterPair;
    const dateMatch = !filterDate || item.date === filterDate;
    return pairMatch && dateMatch;
  });

  return (
    <div className="container py-4">
      <h1 className="display-5 fw-bold mb-4">Analysis History</h1>

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Filter by Pair</label>
              <select
                className="form-select"
                value={filterPair}
                onChange={(e) => setFilterPair(e.target.value)}
              >
                {uniquePairs.map(pair => (
                  <option key={pair} value={pair}>{pair}</option>
                ))}
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label">Filter by Date</label>
              <input
                type="date"
                className="form-control"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* History Table */}
      <div className="card">
        <div className="table-responsive">
          <table className="table table-hover mb-0">
            <thead>
              <tr>
                <th>Date</th>
                <th>Pair</th>
                <th>Sentiment</th>
                <th>Signal Strength</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length > 0 ? (
                filteredData.map((item) => (
                  <tr key={item.id}>
                    <td>{item.date}</td>
                    <td><strong>{item.pair}</strong></td>
                    <td>
                      <span className={`badge ${getSentimentBadge(item.sentiment)}`}>
                        {item.sentiment}
                      </span>
                    </td>
                    <td>
                      <div className="signal-strength">
                        {[1, 2, 3, 4, 5].map(level => (
                          <div
                            key={level}
                            className={`signal-dot ${level <= item.signalStrength ? 'filled' : ''}`}
                          />
                        ))}
                      </div>
                    </td>
                    <td>
                      <button
                        className="btn btn-sm btn-primary"
                        onClick={() => navigate(`/analysis/${item.pair.replace('/', '-')}`)}
                      >
                        <Eye size={16} className="me-1" />
                        View
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="text-center py-4" style={{ color: '#94a3b8' }}>
                    No analyses found matching your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stats */}
      <div className="row g-3 mt-4">
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h3 className="h2 mb-0">{HISTORY_DATA.length}</h3>
              <small style={{ color: '#94a3b8' }}>Total Analyses</small>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h3 className="h2 mb-0 text-success">
                {HISTORY_DATA.filter(item => item.sentiment === 'Bullish').length}
              </h3>
              <small style={{ color: '#94a3b8' }}>Bullish Signals</small>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h3 className="h2 mb-0 text-danger">
                {HISTORY_DATA.filter(item => item.sentiment === 'Bearish').length}
              </h3>
              <small style={{ color: '#94a3b8' }}>Bearish Signals</small>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
